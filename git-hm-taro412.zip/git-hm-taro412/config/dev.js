

export default {
  
  mini: {},
  h5: {}
}
