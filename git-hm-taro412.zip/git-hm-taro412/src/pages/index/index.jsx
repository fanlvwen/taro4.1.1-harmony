import { View, Text } from '@tarojs/components'
import { useLoad } from '@tarojs/taro'
import './index.scss'

export default function Index () {
  useLoad(() => {
    console.log('Page loaded.')
  })
 const useFontFamily = ()=> {
    return {fontFamily: 'iconfont'}
  }
  return (
    <View className='index'>
      <Text>Hello world!ssssssssssssssss</Text>
      <Text>!!!!!taro!!!!!</Text>
      <Text style={{fontFamily: 'iconfont',fontSize: '20px',color: 'red'}}>{`\ue731`}</Text>
    </View>
  )
}
