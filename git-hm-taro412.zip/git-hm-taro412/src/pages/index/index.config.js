export default definePageConfig({
  navigationBarTitleText: '首页'
})
