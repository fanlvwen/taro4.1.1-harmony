export default defineAppConfig({
  pages: [
    'pages/index/index',
    'pages/index/index1',
    'pages/index/index2',
    'pages/index/index3',
  ],
  window: {
    backgroundTextStyle: 'light',
    navigationBarBackgroundColor: '#fff',
    navigationBarTitleText: 'WeChat',
    navigationBarTextStyle: 'black'
  },
  /**
   * tabBar配置
   */
  // tabBar: {
  //   color: '#A6A6A6', selectedColor: '#04bc30', backgroundColor: "#ffffff", borderStyle: "white",
  //   list: [{
  //     pagePath: 'pages/index/index',
  //     text: "首页",
  //     iconPath: "./ass/ac_jpdd_syaf.png",
  //     selectedIconPath: "./ass/ac_jpdd_syaf.png",
  //   },
  //     {
  //       pagePath: 'pages/index/index1',
  //       text: "优惠券",
  //       iconPath: "./ass/ac_jpdd_syaf.png",
  //       selectedIconPath: "./ass/ac_jpdd_syaf.png",
  //     }]
  // }
})
